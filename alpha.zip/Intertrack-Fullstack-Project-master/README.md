# Intertrack-Fullstack-Project
A full stack project at Stutern that involves the use of React for the frontend and NodeJs for the backend. It's a an insurance app, that lets registered users buy various insurance products, and also lay claim(s) when in need.
