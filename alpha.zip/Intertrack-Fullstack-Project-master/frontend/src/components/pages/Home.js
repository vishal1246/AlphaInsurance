import React, { Fragment } from 'react';

import ProductList from '../layouts/ProductList';

const Home = () => {
  return (
    <Fragment>
      <ProductList />
    </Fragment>
  );
};

export default Home;
