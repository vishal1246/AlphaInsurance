import React from 'react';
import Image3 from '../../img/health.png';
import token from "../../img/token.jpeg";

const Health = () => {
  return (
    <section className='insure mt-4'>
      <h1 className='text-center mt-5 mb-5'>
      Life & Health Insurance
        
      </h1>
      <div className='container mt-5'>
        <div className='row  '>
          <div className='col-md-6 col-sm-12 my-4'>
            <h2>Our Premimum Plan</h2>
            <h3>(5 Years)</h3>
            <br />
            <img src={token} style={{width:"130px", cursor:"pointer"}} alt="" />
            
          </div>
          <div className='col-md-6 col-sm-12 my-4'>
            <div className='float-md-right'>
              <img src={Image3} alt='' className='insureImages mb-3' />
              <ol>
                <li>Your Policy security</li>
                <li>This details security</li>
                <li>happy product your</li>
              </ol>
            </div>
          </div>
         
         
          
          
        
        </div>
        
        <div className='text-center mt-5 mb-md-5'>
          <h4 className='ml-md-5'>
            Do you know our products are
            <br /> customisable?
          </h4>
          <button type='button' className='insureContactBtn btn btn-lg mt-3  '>
            Contact Us
          </button>
        </div>
      </div>
    </section>
  );
};

export default Health;
