import React from 'react';
import InstagramIcon from '../../icons/instagramIcon';
import FacebookIcon from '../../icons/facebookIcon';
import TwitterIcon from '../../icons/twitterIcon';
import YoutubeIcon from '../../icons/youtubeIcon';
import MediumIcon from '../../icons/mediumIcon';


const Footer = () => {
  return (
    <section className='footer '>
      <div className='footerTop mt-4 mt-sm-5'>
        <div className='followUs '>
          <h6 className='mb-4'>FOLLOW US</h6>
          <InstagramIcon className='mr-4' />
          <FacebookIcon className='mr-4' />
          <TwitterIcon className='mr-4' />
          <YoutubeIcon className='mr-4' />
          <MediumIcon className='mr-4' />
        </div>

        
      </div>
      <div className='footerSide'>Alpha</div>
      <div className='footerBody'>
        Insurance provided by Alpha Insurance Company, chandigarh , chitkara university <br className='break' /> Alpha Insurance
        Agency (AIA) is acting as the agent of Alpha Insurance Company in
        selling this insurance policy. 
        <br className='break' />
        policies it sells. Further information is available upon request.
      </div>
    </section>
  );
};

export default Footer;
