const { Client } = require("pg");
require("dotenv").config();
const conString =  'postgres://postgres:1234567890@localhost:5432/insurance';
const client = new Client(conString);
client.connect();
module.exports = client;
